struct Tile {
    char color;
};